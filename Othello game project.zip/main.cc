// Frank MacDonald
// November 27th 2017
// Final Project
// Cs2401
// Mr.Dolan
/*
*/
#include <cctype>
#include <cstdlib>
#include <iostream>
#include <string>
#include "othello.h"
#include "space.h"
#include "game.h"
#include "colors.h"

using namespace std;
using namespace main_savitch_14;

int main()
{
   Othello Mygame;
   Mygame.play();

return 0;
}

